$(document).on("click", ".question_product,.faq_question,.column_testimonial_heading_slider_new,.included_faq_question", function (e) {
  if (jQuery(this).hasClass("active")) {
    jQuery(this).toggleClass('active');
    jQuery(this).next().slideToggle();
  } else {
    jQuery('.question_product,.faq_question,.column_testimonial_heading_slider_new,.included_faq_question').removeClass('active');
    jQuery('.question_product,.faq_question,.column_testimonial_heading_slider_new,.included_faq_question').next().slideUp();
    jQuery(this).toggleClass('active');
    jQuery(this).next().slideToggle();
  }
});

$(document).on("click", ".footer_menu_lp p", function (e) {
  if (jQuery(this).hasClass("active")) {
    jQuery(this).toggleClass('active');
    jQuery(this).next().slideToggle();
  } else {
    jQuery('.footer_menu_lp p').removeClass('active');
    jQuery('.footer_menu_lp p').next().slideUp();
    jQuery(this).toggleClass('active');
    jQuery(this).next().slideToggle();
  }
});
$(document).on("click", ".custom_button", function (e) {
    var video = jQuery(this).parents('.video_wrapper_custom').find('video');
if (jQuery(this).hasClass("active")) {
   jQuery(this).parents('.video_wrapper_custom').removeClass('video-active');
    jQuery(this).removeClass('active');
video.trigger('pause');
} else {
video.trigger('play');
  jQuery(this).parents('.video_wrapper_custom').addClass('video-active');
    jQuery(this).addClass('active');
}
});

$(document).on("click", "a[href='#reviews']", function (e) {
  e.preventDefault();
  document.querySelector('#reviews').scrollIntoView({
    behavior: 'smooth'
  })
});



jQuery(document).ready(function(){
if(navigator.userAgent.indexOf('Mac') > 0) {
jQuery('body').addClass('mac-os');
} else {
jQuery('body').addClass('window-os');
}
});



$(window).scroll(function () {
    $('.custom_icons_with_text_landing_page.nasties_list .icons_with_text_item_flex').each(function () {
        if (isScrolledIntoView2(this) === true) {
            $(this).addClass('active');
        } else {
          $(this).removeClass('active');
        }
    });

});


function isScrolledIntoView2(elem) {
    var docViewTop = $(window).scrollTop();
    var docViewBottom = docViewTop + $(window).height();
docViewBottom = docViewBottom-($(window).height())+($(elem).height())+350;
    var elemTop = $(elem).offset().top;
    var elemBottom = elemTop + $(elem).height();

    return ((elemBottom <= docViewBottom));
}


$(window).scroll(function () {


    $('.difference_lp .icons_with_text_flex').each(function () {
      var this_element =  $(this);
      if (this_element.hasClass("start_count")) {
} else {
        if (isScrolledIntoView2(this) === true) {
            this_element.addClass('start_count');
$('.count_js').each(function () {
    $(this).prop('Counter', 0).animate({
            Counter: $(this).data('value')
        }, {
        duration: 1500,
        easing: 'swing',
        step: function (now) {                      
            $(this).text(Math.ceil(now));
        }
    });
});
        }
      }
    });


  $('.balance_bottom_lp .rich-text_custom__richtext.balance_ul_custom li').each(function () {
        if (isScrolledIntoView2(this) === true) {
            $(this).addClass('active');
        } else {
          $(this).removeClass('active');
        }
    });

  
});


function isScrolledIntoView2(elem) {
    var docViewTop = $(window).scrollTop();
    var docViewBottom = docViewTop + $(window).height();
docViewBottom = docViewBottom-($(window).height())+($(elem).height())+450;
    var elemTop = $(elem).offset().top;
    var elemBottom = elemTop + $(elem).height();

    return ((elemBottom <= docViewBottom));
}


$(document).on("click", '.custom_add_to_cart_box', function(e) { 
var data_tab = $(this).attr('data_id');
$('.custom_popup_main[data_tab="'+data_tab+'"]').eq(0).show();
$('.custom_popup_main[data_tab="'+data_tab+'"]').eq(0).addClass('active');
$('.custom_popup_main[data_tab="'+data_tab+'"]').eq(0).find('.slick-slider').slick('refresh');
});
$(document).on("click", '.close_popup,.custom_popup_bg', function(e) { 
$('.custom_popup_main').hide();
$('.custom_popup_main').removeClass('active');
});

$(document).on("click", '.close_menu,.custom_menu_bg', function(e) { 
$('summary.mobile-toggle').trigger('click');
});


$(document).on("click", '.menu_middle_custom_item', function(e) { 
var data_tab = $(this).attr('data_tab');
$('.custom_products_popup[data_tab="'+data_tab+'"]').addClass('active');
});

$(document).on("click", '.close_submenu', function(e) { 
$('.custom_products_popup').removeClass('active');
});
$(document).on("click", 'a.remove', function(e) { 
  e.preventDefault();
});



$(document).on("click", '.option_item', function(e) { 
$(this).parents('.landing_page_product').find('.option_item').removeClass('active');
$(this).addClass('active');
var selected_variant = $(this).attr('variant_id');
$(this).parents('.landing_page_product').find('span.custom_checkout_button').attr('variant_id',selected_variant); 
$(this).parents('.landing_page_product').find('.price_trigger').hide();
$(this).parents('.landing_page_product').find('.custom_checkout_button_landing_page .price_trigger').removeClass('active');
$(this).parents('.landing_page_product').find('.custom_checkout_button_landing_page .price_trigger[data_tab="'+selected_variant+'"]').addClass('active');
$(this).parents('.landing_page_product').find('.price_trigger[data_tab="'+selected_variant+'"]').show();
var image_src= $(this).attr('image_src');
var image = $(this).parents('.landing_page_product').find('.product-main-slider img[src="'+image_src+'"]');
image_index = image.attr('data-slick-index');
$(this).parents('.landing_page_product').find('.product-main-slider').slick('slickGoTo', image_index);
});



$(document).on("click", '.trigger_custom_ajax_cart', function(e) {
e.preventDefault(); 
var this_element =  jQuery(this);
this_element.addClass('loading_hk');
var id = jQuery(this).attr('variant_id');
var selling_plan = jQuery(this).attr('selling_plan');
if(selling_plan != null && selling_plan != ""){
jQuery.ajax({
type: 'POST',
url: '/cart/add.js',
data: {
  quantity: 1,
  id: id,
  selling_plan: selling_plan
},
  dataType: 'json', 
 success: function (data) { 
$('.custom_popup_main').hide();
  
jQuery("#Cart-Drawer").load(location.href + " #cart_refresh_drawer");
jQuery("#cart-drawer-toggle").load(location.href + " #cart_icon_refresh");
setTimeout(function() {
jQuery("#Cart-Drawer").addClass('active');
jQuery("body ").addClass('open-cc open-cart');
this_element.removeClass('loading_hk'); 
}, 500);
 } 
 });

} else {
jQuery.ajax({
type: 'POST',
url: '/cart/add.js',
data: {
  quantity: 1,
  id: id
},
  dataType: 'json', 
 success: function (data) { 
$('.custom_popup_main').hide();
  
jQuery("#Cart-Drawer").load(location.href + " #cart_refresh_drawer");
jQuery("#cart-drawer-toggle").load(location.href + " #cart_icon_refresh");
setTimeout(function() {
jQuery("#Cart-Drawer").addClass('active');
jQuery("body ").addClass('open-cc open-cart');
this_element.removeClass('loading_hk'); 
}, 500);
 } 
 });
}
  });


$(document).on("click", "body .quantity .minus.disabled[quantity='1']", function (e) {
  e.preventDefault();
var quantity =  $(this).parents('.cart_bottom_flex').find('quantity-selector.quantity input').val();
if (quantity == 1){
var remove_link = $(this).parents('.cart_bottom_flex').find('a.remove').attr('href');
$(this).parents('.product-cart-item').addClass('thb-loading');
jQuery.ajax({
type: 'POST',
url: remove_link, 
 success: function (data) { 
jQuery("#Cart-Drawer").load(location.href + " #cart_refresh_drawer");
jQuery("#cart-drawer-toggle").load(location.href + " #cart_icon_refresh");
setTimeout(function() {
jQuery("#Cart-Drawer").addClass('active');
jQuery("body ").addClass('open-cc open-cart');
}, 500);
 } 
 });
}
});


$(document).on("mousemove touchstart", "body", function(e) { 
if( $('.slider_cart_drawer:not(.slick-initialized)').length ) {
    $('.slider_cart_drawer:not(.slick-initialized)').slick({
  dots: true,
  speed: 300,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: false,
  infinite: true,
    prevArrow: $('.prev_cart_drawer'),
    nextArrow: $('.next_cart_drawer'),
    appendDots: $('.dots_cart_drawer'),
  cssEase:'linear',
  responsive: [
    {
      breakpoint: 915,
      settings: {
        speed: 300,
        slidesToShow:1, 
      }
    }
  ]
});
}
});




$(document).on("click", '.subscription_item', function(e) {
$(this).parents('.custom_variants_landing_page').find('.subscription_item').removeClass('active');  
$(this).addClass('active');  
var selected_tab = $(this).attr('data_tab');
if (selected_tab == '2'){
var selling_plan = $(this).attr('selling_plan');
$(this).parents('.landing_product_flex').find('.trigger_custom_ajax_cart').attr('selling_plan',selling_plan);
} else {
$(this).parents('.landing_product_flex').find('.trigger_custom_ajax_cart').removeAttr('selling_plan');
}
$(this).parents('.landing_product_flex').find('.subscription_trigger').hide();
$(this).parents('.landing_product_flex').find('.subscription_trigger[data_tab="'+selected_tab+'"]').show();
});




$(document).on("click", "span.custom_checkout_button.custom_lp_button.trigger_custom_ajax_cart2.custom_hk_button", function (e) {
  e.preventDefault();
  document.querySelector('.custom_variants_landing_page').scrollIntoView({
    behavior: 'smooth'
  })
});
